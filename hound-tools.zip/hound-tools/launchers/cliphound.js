ObjC.import('AppKit');
ObjC.import('Foundation');

var app = Application.currentApplication();
app.includeStandardAdditions = true;

var PYTHON3 = "/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3";
var SCRIPT  = "/Users/stevenwilson/Documents/Aceable/cliphound/agent.py";
var LOGO    = "/Users/stevenwilson/Documents/Aceable/cliphound/ClipHound_App_Logo.png";
var PREVIEW_PATH_FILE = "/tmp/cliphound_preview_path.txt";

function activate() {
    $.NSApplication.sharedApplication.activateIgnoringOtherApps(true);
}

function shellQuote(s) {
    return "'" + s.replace(/'/g, "'\\''") + "'";
}

function openPreviewFolder() {
    try {
        var pathData = $.NSString.stringWithContentsOfFileEncodingError(
            PREVIEW_PATH_FILE, $.NSUTF8StringEncoding, null);
        var folderPath = ObjC.unwrap(pathData).trim();
        if (folderPath) {
            $.NSWorkspace.sharedWorkspace.openFile(folderPath);
        }
    } catch(e) {}
}

function mainDialog() {
    var W = 500, logoSize = 480, midPad = 46, bottomPad = 14, fieldH = 28;
    var accessoryH = logoSize + midPad + fieldH + bottomPad;

    var view = $.NSView.alloc.initWithFrame($.NSMakeRect(0, 0, W, accessoryH));

    // Logo — flush to top of accessory, centered horizontally
    var lx = (W - logoSize) / 2;
    var ly = bottomPad + fieldH + midPad;
    var iv = $.NSImageView.alloc.initWithFrame($.NSMakeRect(lx, ly, logoSize, logoSize));
    iv.image = $.NSImage.alloc.initWithContentsOfFile(LOGO);
    iv.imageScaling = 3;
    view.addSubview(iv);

    // Search field
    var tf = $.NSSearchField.alloc.initWithFrame($.NSMakeRect(0, bottomPad, W, fieldH));
    tf.placeholderString = "Search your footage library\u2026";
    view.addSubview(tf);

    var alert = $.NSAlert.alloc.init;
    alert.messageText = "";
    alert.icon = $.NSImage.alloc.initWithSize($.NSMakeSize(1, 1));
    alert.accessoryView = view;
    alert.addButtonWithTitle("Search");           // response 1000
    alert.addButtonWithTitle("Cancel");           // response 1001
    alert.addButtonWithTitle("Index New Clips");  // response 1002

    // Light blue Search button using Aceable teal
    alert.buttons.objectAtIndex(0).bezelColor = $.NSColor.colorWithRedGreenBlueAlpha(0.071, 0.741, 0.804, 1.0);
    alert.window.initialFirstResponder = tf;

    activate();
    var r = ObjC.unwrap(alert.runModal);

    if (r === 1001) return { action: "cancel" };
    if (r === 1002) return { action: "index" };
    var q = ObjC.unwrap(tf.stringValue).trim();
    if (!q) return { action: "cancel" };
    return { action: "search", query: q };
}

function orientDialog() {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = "Filter by orientation?";
    alert.addButtonWithTitle("Any");         // 1000
    alert.addButtonWithTitle("Horizontal");  // 1001
    alert.addButtonWithTitle("Vertical");    // 1002
    activate();
    var r = ObjC.unwrap(alert.runModal);
    if (r === 1001) return " --horizontal";
    if (r === 1002) return " --vertical";
    return "";
}

function continueDialog(query) {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = "Finder is open with results for \u201c" + query + "\u201d.";
    alert.addButtonWithTitle("Done");    // 1000
    alert.addButtonWithTitle("Next 12"); // 1001
    activate();
    var r = ObjC.unwrap(alert.runModal);
    return r === 1001;
}

function run() {
    activate();

    var d = mainDialog();
    if (d.action === "cancel") return;

    if (d.action === "index") {
        app.doShellScript(PYTHON3 + " " + SCRIPT + " index > /tmp/cliphound_index.log 2>&1 &");
        var a = $.NSAlert.alloc.init;
        a.messageText = "Indexing started in the background.";
        a.informativeText = "ClipHound is scanning for new clips.";
        a.addButtonWithTitle("OK");
        activate();
        a.runModal;
        return;
    }

    var query  = d.query;
    var orient = orientDialog();
    var offset = 0;

    while (true) {
        var cmd = PYTHON3 + " " + SCRIPT + " search " + shellQuote(query) + orient + " --offset " + offset;
        var output = "";
        try { output = app.doShellScript(cmd); } catch(e) { output = e.toString(); }

        if (output.indexOf("No results") !== -1 || output.indexOf("0 clip") !== -1) {
            var na = $.NSAlert.alloc.init;
            na.messageText = offset === 0
                ? "No clips found for \u201c" + query + "\u201d."
                : "No more clips for \u201c" + query + "\u201d.";
            na.addButtonWithTitle("OK");
            activate();
            na.runModal;
            break;
        }

        // Open preview folder via NSWorkspace — no nested osascript/JXA
        openPreviewFolder();

        if (!continueDialog(query)) break;
        offset += 12;
    }
}

