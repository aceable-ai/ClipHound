ObjC.import('AppKit');
ObjC.import('Foundation');

var app = Application.currentApplication();
app.includeStandardAdditions = true;

var PYTHON3      = "/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3";
var SCRIPT       = "/Users/stevenwilson/Documents/Aceable/soundhound/agent.py";
var LOGO         = "/Users/stevenwilson/Downloads/SoundHound_App_Logo.png";
var PREVIEW_FILE = "/tmp/soundhound_preview_path.txt";

function activate() {
    $.NSApplication.sharedApplication.activateIgnoringOtherApps(true);
}

function shellQuote(s) {
    return "'" + s.replace(/'/g, "'\\''") + "'";
}

function openPreviewFolder() {
    try {
        var pathData = $.NSString.stringWithContentsOfFileEncodingError(
            PREVIEW_FILE, $.NSUTF8StringEncoding, null);
        var folderPath = ObjC.unwrap(pathData).trim();
        if (folderPath) $.NSWorkspace.sharedWorkspace.openFile(folderPath);
    } catch(e) {}
}

function mainDialog() {
    var W         = 500;
    var logoSize  = 480;
    var bottomPad = 14;
    var checkH    = 20;
    var checkGap  = 8;   // gap between checkboxes and search field
    var fieldH    = 28;
    var midPad    = 26;  // gap between search field and logo

    // Layout bottom-up: checkboxes → search field → logo
    var checkY  = bottomPad;
    var fieldY  = checkY + checkH + checkGap;
    var logoY   = fieldY + fieldH + midPad;
    var accessoryH = logoY + logoSize;

    var view = $.NSView.alloc.initWithFrame($.NSMakeRect(0, 0, W, accessoryH));

    // Logo — top, centered
    var lx = (W - logoSize) / 2;
    var iv = $.NSImageView.alloc.initWithFrame($.NSMakeRect(lx, logoY, logoSize, logoSize));
    iv.image = $.NSImage.alloc.initWithContentsOfFile(LOGO);
    iv.imageScaling = 3;
    view.addSubview(iv);

    // Search field — full width
    var tf = $.NSSearchField.alloc.initWithFrame($.NSMakeRect(0, fieldY, W, fieldH));
    tf.placeholderString = "Search music and sound effects\u2026";
    view.addSubview(tf);

    // SFX (left) + Music (right) checkboxes — centered below search field
    var sfxW   = 52;
    var musicW = 70;
    var btnSpacing = 6;
    var totalW = sfxW + btnSpacing + musicW;
    var startX = (W - totalW) / 2;

    var sfxBtn = $.NSButton.alloc.initWithFrame(
        $.NSMakeRect(startX, checkY, sfxW, checkH));
    sfxBtn.setButtonType(3);  // NSSwitchButton
    sfxBtn.title = "SFX";
    sfxBtn.state = 1;         // SFX on by default
    view.addSubview(sfxBtn);

    var musicBtn = $.NSButton.alloc.initWithFrame(
        $.NSMakeRect(startX + sfxW + btnSpacing, checkY, musicW, checkH));
    musicBtn.setButtonType(3);
    musicBtn.title = "Music";
    musicBtn.state = 0;
    view.addSubview(musicBtn);

    var alert = $.NSAlert.alloc.init;
    alert.messageText = "";
    alert.icon = $.NSImage.alloc.initWithSize($.NSMakeSize(1, 1));
    alert.accessoryView = view;
    alert.addButtonWithTitle("Search");           // 1000
    alert.addButtonWithTitle("Cancel");           // 1001
    alert.addButtonWithTitle("Index New Audio");  // 1002

    alert.buttons.objectAtIndex(0).bezelColor = $.NSColor.colorWithRedGreenBlueAlpha(0.071, 0.741, 0.804, 1.0);
    alert.window.initialFirstResponder = tf;

    activate();
    var r = ObjC.unwrap(alert.runModal);

    if (r === 1001) return { action: "cancel" };
    if (r === 1002) return { action: "index" };

    var q = ObjC.unwrap(tf.stringValue).trim();
    if (!q) return { action: "cancel" };

    // Read toggle states — NSButton.state is a plain JS integer in JXA (no unwrap needed)
    var musicOn = musicBtn.state == 1;
    var sfxOn   = sfxBtn.state   == 1;
    var typeFlag  = sfxOn && !musicOn ? " --sfx" : musicOn && !sfxOn ? " --music" : "";
    var typeLabel = sfxOn && !musicOn ? "SFX"    : musicOn && !sfxOn ? "Music"    : "Audio";

    return { action: "search", query: q, typeFlag: typeFlag, typeLabel: typeLabel };
}

function continueDialog(query, typeLabel) {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = "Finder is open with " + typeLabel + " results for \u201c" + query + "\u201d.";
    alert.addButtonWithTitle("Done");
    alert.addButtonWithTitle("Next 12");
    activate();
    return ObjC.unwrap(alert.runModal) === 1001;
}

function run() {
    activate();

    var d = mainDialog();
    if (d.action === "cancel") return;

    if (d.action === "index") {
        app.doShellScript(PYTHON3 + " " + SCRIPT + " index > /tmp/soundhound_index.log 2>&1 &");
        var a = $.NSAlert.alloc.init;
        a.messageText = "Indexing started in the background.";
        a.informativeText = "SoundHound is scanning for new audio files.";
        a.addButtonWithTitle("OK");
        activate();
        a.runModal;
        return;
    }

    var query     = d.query;
    var typeFlag  = d.typeFlag;
    var typeLabel = d.typeLabel;
    var offset    = 0;

    while (true) {
        var cmd = PYTHON3 + " " + SCRIPT + " search " + shellQuote(query) + typeFlag + " --offset " + offset;
        var output = "";
        try { output = app.doShellScript(cmd); } catch(e) { output = e.toString(); }

        if (output.indexOf("No results") !== -1 || output.indexOf("0 result") !== -1) {
            var na = $.NSAlert.alloc.init;
            na.messageText = offset === 0
                ? "No " + typeLabel + " found for \u201c" + query + "\u201d."
                : "No more results for \u201c" + query + "\u201d.";
            na.addButtonWithTitle("OK");
            activate();
            na.runModal;
            break;
        }

        openPreviewFolder();

        if (!continueDialog(query, typeLabel)) break;
        offset += 12;
    }
}

