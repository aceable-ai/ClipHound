from __future__ import annotations
import re

# ---------- VO / Narration exclusion ----------
# These are NEVER indexed — project-specific recordings, not reusable assets

_VO_PATH_PATTERNS = [
    r'/vo/',
    r'/02_audio/',
    r'/narration/',
    r'/voice/',
    r'captured audio',
]

_VO_FILENAME_PATTERNS = [
    r'_vo_',
    r'^vo_',
    r'_vo\.',
    r'\bnarration\b',
    r'\bvoiceover\b',
    r'voice.?over',
    r'_VO\b',
]


def is_vo(path: str, filename: str) -> bool:
    p = path.lower()
    f = filename.lower()
    return (
        any(re.search(pat, p) for pat in _VO_PATH_PATTERNS) or
        any(re.search(pat, f) for pat in _VO_FILENAME_PATTERNS)
    )


# ---------- SFX vs Music classification ----------

_SFX_PATH_PATTERNS = [
    r'/04_sfx',
    r'/sfx/',
    r'sfx$',
    r'sound.?effect',
    r'/foley',
    r'/whoosh',
    r'/swoosh',
    r'/transition',
    r'/clicks',
    r'/alarm',
    r'vehicl',
    r'ui.and.trans',
    r'intro.outro.audio',
]

_MUSIC_PATH_PATTERNS = [
    r'/05_music',
    r'/music/',
    r'artlist',
    r'2025 music',
    r'/soundtrack',
    r'/score',
    r'/tracks/',
    r'epidemic',
]

_SFX_FILENAME_PATTERNS = [
    r'whoosh',
    r'swoosh',
    r'foley',
    r'impact',
    r'transition',
    r'click',
    r'beep',
    r'buzz',
    r'rattle',
    r'drive.?by',
    r'highway',
    r'gear.?shift',
    r'engine',
]


def classify_track(data: dict) -> str:
    """Returns 'music' | 'sfx'."""
    path     = (data.get("path")     or "").lower()
    filename = (data.get("filename") or "").lower()
    duration = data.get("duration_s") or 0
    bpm      = data.get("bpm")
    artist   = (data.get("artist")  or "").strip()
    genre    = (data.get("genre")   or "").lower()

    # --- Folder-based (strongest signal) ---
    if any(re.search(p, path) for p in _SFX_PATH_PATTERNS):
        return "sfx"
    if any(re.search(p, path) for p in _MUSIC_PATH_PATTERNS):
        return "music"

    # --- Filename patterns ---
    if any(re.search(p, filename) for p in _SFX_FILENAME_PATTERNS):
        return "sfx"

    # --- Metadata signals ---
    if bpm and float(bpm) > 0:
        return "music"
    if artist:
        return "music"
    if genre and not any(x in genre for x in ["sound", "effect", "foley", "sfx", "noise"]):
        return "music"

    # --- Duration fallback ---
    if duration > 60:
        return "music"
    if duration < 30:
        return "sfx"

    return "sfx"  # default for ambiguous files


def parse_artlist_slug(folder_name: str) -> str:
    """
    Convert Artlist-style folder slugs to readable keywords.
    'chill-lofi-hip-hop-2025-01-16-01-30-00-utc' → 'chill lofi hip hop'
    """
    # Strip trailing timestamp: -YYYY-MM-DD-HH-MM-SS-utc
    cleaned = re.sub(r'-\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}-utc$', '', folder_name)
    cleaned = re.sub(r'-\d{4}-\d{2}-\d{2}.*$', '', cleaned)
    return cleaned.replace('-', ' ').replace('_', ' ').strip()


def stem_group_key(filename: str) -> str:
    """
    Normalize filename to a stem group key for deduplication of variants.
    'Chill LoFi Hip-Hop (no vocal mix).wav' → 'chill lofi hip-hop'
    'Fast Whoosh 1.wav' → 'fast whoosh'
    """
    stem = re.sub(r'\.[^.]+$', '', filename)          # strip extension
    stem = re.sub(r'\s*\([^)]*\)', '', stem)           # strip (parenthetical variants)
    stem = re.sub(r'\s*\[[^\]]*\]', '', stem)          # strip [bracketed variants]
    stem = re.sub(r'[\s_]+\d+$', '', stem)             # strip trailing numbers
    return stem.strip().lower()
