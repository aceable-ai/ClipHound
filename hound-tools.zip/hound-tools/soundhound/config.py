import os
from pathlib import Path

# Directories to scan for audio files
WATCH_PATHS = [
    "/Volumes/Ace Drive A/Broll Archive",
    "/Volumes/Ace Drive A/2026",
    "/Volumes/Ace Drive A/Long Form Videos",
]

# Local data directory
DATA_DIR = Path.home() / ".soundhound"
DB_PATH   = DATA_DIR / "index.db"

# Claude model for keyword generation (text only — no vision needed)
AI_MODEL = "claude-haiku-4-5-20251001"

# Preview folder on Desktop
PREVIEW_DIR = Path.home() / "Desktop" / "SoundHound Results"

# Supported audio extensions
AUDIO_EXTENSIONS = {".mp3", ".wav", ".aif", ".aiff", ".m4a", ".flac"}
