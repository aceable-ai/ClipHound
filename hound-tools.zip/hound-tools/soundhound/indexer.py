from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import anthropic
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn

from config import WATCH_PATHS, AUDIO_EXTENSIONS, AI_MODEL
from classifier import is_vo, classify_track, parse_artlist_slug, stem_group_key
from database import init_db, upsert_track, path_exists_in_db

console = Console()

AI_PROMPT = """\
Generate 8-12 search keywords for this audio file. \
Focus on mood, energy, tempo feel, genre, instruments, and video use cases \
(e.g. "upbeat", "corporate", "tense", "car engine", "transition", "UI click"). \
Return ONLY a comma-separated list — no explanation, no numbering."""


def collect_audio_files(paths: list[str]) -> list[Path]:
    files = []
    for root in paths:
        p = Path(root)
        if not p.exists():
            console.print(f"[yellow]Warning:[/yellow] Path not found: {root}")
            continue
        for f in p.rglob("*"):
            if (f.is_file()
                    and f.suffix.lower() in AUDIO_EXTENSIONS
                    and not f.name.startswith("._")
                    and not is_vo(str(f), f.name)):
                files.append(f)
    return sorted(files)


def probe_audio(path: Path) -> dict:
    """Extract duration and size via ffprobe."""
    try:
        import json
        cmd = [
            "/opt/homebrew/bin/ffprobe", "-v", "quiet",
            "-print_format", "json",
            "-show_format",
            str(path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        data = json.loads(result.stdout)
        fmt = data.get("format", {})
        duration = None
        try:
            duration = float(fmt.get("duration", 0)) or None
        except (ValueError, TypeError):
            pass
        size = int(fmt.get("size", 0)) or None
        return {"duration_s": duration, "size_bytes": size}
    except Exception:
        return {}


def extract_metadata(path: Path) -> dict:
    """Extract ID3/metadata tags using mutagen."""
    meta = {}
    try:
        from mutagen import File as MutagenFile
        audio = MutagenFile(path, easy=True)
        if audio is None:
            return meta
        def _get(tag):
            val = audio.get(tag)
            return str(val[0]).strip() if val else None
        meta["title"]   = _get("title")
        meta["artist"]  = _get("artist")
        meta["genre"]   = _get("genre")
        meta["key_sig"] = _get("initialkey") or _get("key")
        bpm_raw = _get("bpm") or _get("tbpm")
        if bpm_raw:
            try:
                meta["bpm"] = float(re.sub(r'[^\d.]', '', bpm_raw))
            except ValueError:
                pass
        # Duration from mutagen is more reliable for audio than ffprobe
        if hasattr(audio, 'info') and hasattr(audio.info, 'length'):
            meta["duration_s"] = audio.info.length
    except Exception:
        pass
    return meta


def extract_project_name(path: Path) -> str | None:
    """Pull SM-XXX or campaign project name from the path."""
    for part in path.parts:
        if re.search(r'SM-\d+', part):
            m = re.search(r'(SM-\d+[^/]*)', part)
            return m.group(1) if m else part
        if part in ("Ace Mode Launch", "Ace Mode_concepts", "Long Form Videos"):
            return part
    return None


def count_uses(path: Path, all_files: list[Path]) -> int:
    """Count how many copies of this filename exist across all indexed paths."""
    return sum(1 for f in all_files if f.name == path.name)


def generate_keywords(client: anthropic.Anthropic, filename: str,
                      folder_name: str, duration_s: float | None,
                      bpm: float | None, genre: str | None,
                      artist: str | None) -> str | None:
    """Ask Claude for keyword tags. Only called when filename is ambiguous."""
    parts = [f"Filename: {filename}"]
    if folder_name:
        parts.append(f"Folder: {folder_name}")
    if duration_s:
        parts.append(f"Duration: {duration_s:.1f}s")
    if bpm:
        parts.append(f"BPM: {bpm}")
    if genre:
        parts.append(f"Genre: {genre}")
    if artist:
        parts.append(f"Artist: {artist}")

    try:
        response = client.messages.create(
            model=AI_MODEL,
            max_tokens=80,
            system=[{"type": "text", "text": AI_PROMPT,
                     "cache_control": {"type": "ephemeral"}}],
            messages=[{"role": "user", "content": "\n".join(parts)}],
        )
        return response.content[0].text.strip()
    except Exception as e:
        console.print(f"[dim red]AI error: {e}[/dim red]")
        return None


def _needs_ai(filename: str, folder_name: str) -> bool:
    """Skip AI for files that are already self-describing."""
    name = filename.lower()
    folder = folder_name.lower()
    # Artlist-style slugs are already rich with keywords
    if re.search(r'[a-z]+-[a-z]+-[a-z]+', folder):
        return False
    # Long descriptive filenames (e.g. Highway_Drive_By_Long_02.wav)
    word_count = len(re.findall(r'[a-z]{3,}', name))
    if word_count >= 3:
        return False
    return True


def run_index(force: bool = False, vision: bool = True):
    init_db()

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if vision and not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set.[/red]")
        return

    ai_client = anthropic.Anthropic(api_key=api_key) if vision else None

    console.print("[bold]Scanning for audio files...[/bold]")
    all_files = collect_audio_files(WATCH_PATHS)
    console.print(f"Found [bold]{len(all_files)}[/bold] audio files (VO excluded)")

    new_files = all_files if force else [f for f in all_files if not path_exists_in_db(str(f))]
    console.print(f"[bold]{len(new_files)}[/bold] files to index")

    if not new_files:
        console.print("[green]Index is up to date.[/green]")
        return

    indexed = errors = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Indexing...", total=len(new_files))

        for f in new_files:
            progress.update(task, description=f"[dim]{f.name[:50]}[/dim]")

            probe   = probe_audio(f)
            meta    = extract_metadata(f)
            # mutagen duration takes priority
            duration = meta.pop("duration_s", None) or probe.get("duration_s")
            size     = probe.get("size_bytes")

            folder_name  = f.parent.name
            project_name = extract_project_name(f)
            use_count    = count_uses(f, all_files)

            # Artlist slug as pre-built keywords (free)
            artlist_keywords = parse_artlist_slug(folder_name)
            has_rich_slug = bool(re.search(r'[a-z]+-[a-z]+-[a-z]+', folder_name.lower()))

            track_data = {
                "path":         str(f),
                "filename":     f.name,
                "folder_name":  folder_name,
                "project_name": project_name,
                "stem_group":   stem_group_key(f.name),
                "ext":          f.suffix.lower(),
                "size_bytes":   size,
                "duration_s":   duration,
                "bpm":          meta.get("bpm"),
                "key_sig":      meta.get("key_sig"),
                "genre":        meta.get("genre"),
                "artist":       meta.get("artist"),
                "title":        meta.get("title"),
                "ai_keywords":  artlist_keywords if has_rich_slug else None,
                "use_count":    use_count,
            }

            track_data["audio_type"] = classify_track({**track_data, "duration_s": duration})

            # Run AI only for ambiguous names and only if not already covered by slug
            if vision and ai_client and not has_rich_slug and _needs_ai(f.name, folder_name):
                track_data["ai_keywords"] = generate_keywords(
                    ai_client, f.name, folder_name, duration,
                    meta.get("bpm"), meta.get("genre"), meta.get("artist")
                )

            try:
                upsert_track(track_data)
                indexed += 1
            except Exception as e:
                console.print(f"[red]DB error for {f.name}: {e}[/red]")
                errors += 1

            progress.advance(task)

    console.print(f"\n[green]Done.[/green] Indexed: {indexed}  Errors: {errors}")
