#!/usr/bin/env python3
from __future__ import annotations
"""
SoundHound — CLI
Usage:
  python agent.py index              # Index new audio files
  python agent.py index --no-ai      # Index metadata only (no Claude API)
  python agent.py index --force      # Re-index everything
  python agent.py search "keyword"   # Search all audio
  python agent.py search "keyword" --music
  python agent.py search "keyword" --sfx
  python agent.py stats
"""
import argparse
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

from rich.console import Console
from rich.table import Table

from database import get_stats, init_db
from indexer import run_index
from searcher import search
from preview import build_preview_folder

console = Console()


def cmd_index(args):
    run_index(force=args.force, vision=not args.no_ai)


def cmd_search(args):
    query = " ".join(args.query)

    audio_type = 'both'
    if getattr(args, 'music', False):
        audio_type = 'music'
    elif getattr(args, 'sfx', False):
        audio_type = 'sfx'

    results = search(query, limit=args.limit, offset=args.offset,
                     audio_type=audio_type)

    if not results:
        console.print(f"[yellow]No results for:[/yellow] {query}")
        return

    label = {"music": "Music", "sfx": "SFX", "both": "Audio"}[audio_type]
    console.print(
        f"\n[bold green]SoundHound — {len(results)} {label} result(s)[/bold green] "
        f"for: [italic]{query}[/italic]\n"
    )

    table = Table(show_header=True, header_style="bold cyan", show_lines=True)
    table.add_column("#",        width=3,  justify="right")
    table.add_column("Filename", min_width=30)
    table.add_column("Type",     width=6)
    table.add_column("Duration", width=8,  justify="right")
    table.add_column("BPM",      width=5,  justify="right")
    table.add_column("Used",     width=5,  justify="right")
    table.add_column("Keywords", min_width=30)

    for i, track in enumerate(results, start=1):
        dur  = _fmt_duration(track.duration_s)
        bpm  = f"{track.bpm:.0f}" if track.bpm else "—"
        used = str(track.use_count) if track.use_count > 1 else "—"
        kw   = (track.ai_keywords or track.genre or "—")[:50]
        table.add_row(str(i), track.filename, track.audio_type, dur, bpm, used, kw)

    console.print(table)

    preview_dir, count = build_preview_folder(results)
    console.print(f"\n[green]Built {count} alias(es) — opening in Finder...[/green]")


def cmd_stats(args):
    init_db()
    s = get_stats()
    console.print("\n[bold]SoundHound — Index Stats[/bold]")
    console.print(f"  Total indexed:  [cyan]{s['total']}[/cyan]")
    console.print(f"  Music:          [cyan]{s['music'] or 0}[/cyan]")
    console.print(f"  SFX:            [cyan]{s['sfx'] or 0}[/cyan]")
    console.print(f"  With AI tags:   [cyan]{s['with_ai'] or 0}[/cyan]")
    console.print(f"  Total duration: [cyan]{s['total_hours'] or 0} hrs[/cyan]")
    console.print(f"  Total size:     [cyan]{s['total_gb'] or 0} GB[/cyan]\n")


def _fmt_duration(secs: float | None) -> str:
    if secs is None:
        return "—"
    m, s = divmod(int(secs), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def main():
    parser = argparse.ArgumentParser(
        prog="soundhound",
        description="SoundHound — search your audio library",
    )
    sub = parser.add_subparsers(dest="command")

    p_index = sub.add_parser("index", help="Scan and index audio files")
    p_index.add_argument("--force",  action="store_true", help="Re-index all files")
    p_index.add_argument("--no-ai",  action="store_true", help="Skip AI keyword generation")
    p_index.set_defaults(func=cmd_index)

    p_search = sub.add_parser("search", help="Search the audio index")
    p_search.add_argument("query",   nargs="+",      help="Search terms")
    p_search.add_argument("--limit", type=int, default=12)
    p_search.add_argument("--offset",type=int, default=0)
    p_search.add_argument("--music", action="store_true", help="Music only")
    p_search.add_argument("--sfx",   action="store_true", help="SFX only")
    p_search.set_defaults(func=cmd_search)

    p_stats = sub.add_parser("stats", help="Show index statistics")
    p_stats.set_defaults(func=cmd_stats)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
