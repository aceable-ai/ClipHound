from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from database import get_conn


@dataclass
class TrackResult:
    id:           int
    path:         str
    filename:     str
    folder_name:  str | None
    project_name: str | None
    stem_group:   str | None
    duration_s:   float | None
    bpm:          float | None
    key_sig:      str | None
    genre:        str | None
    artist:       str | None
    title:        str | None
    audio_type:   str
    ai_keywords:  str | None
    use_count:    int
    rank:         float


def _query_has_long(query: str) -> bool:
    return 'long' in query.lower().split()


def search(query: str, limit: int = 12, offset: int = 0,
           audio_type: str = 'both') -> list[TrackResult]:
    """
    Full-text search across filename, folder, artist, title, genre, ai_keywords.
    Falls back to LIKE if FTS returns nothing.
    Deduplicates by stem_group (keeps best-ranked variant per track).
    audio_type: 'music' | 'sfx' | 'both'
    """
    fetch = (offset + limit) * 4
    conn  = get_conn()
    allow_long = _query_has_long(query)

    results = _fts_search(conn, query, fetch, audio_type, allow_long)
    if not results:
        results = _like_search(conn, query, fetch, audio_type, allow_long)

    conn.close()
    return _dedupe(results, limit, offset)


def _type_filter(audio_type: str, allow_long: bool = False) -> str:
    if audio_type == 'music':
        return "AND t.audio_type = 'music'"
    if audio_type == 'sfx':
        # Hard duration gate: nothing over 30s in SFX, period — unless query contains "long"
        dur = "" if allow_long else "AND t.duration_s <= 30"
        return f"AND t.audio_type = 'sfx' {dur}"
    return ""


def _fts_search(conn: sqlite3.Connection, query: str, limit: int,
                audio_type: str, allow_long: bool = False) -> list[TrackResult]:
    fts_q  = _build_fts_query(query)
    tf     = _type_filter(audio_type, allow_long)
    try:
        rows = conn.execute(f"""
            SELECT t.id, t.path, t.filename, t.folder_name, t.project_name,
                   t.stem_group, t.duration_s, t.bpm, t.key_sig, t.genre,
                   t.artist, t.title, t.audio_type, t.ai_keywords, t.use_count,
                   bm25(tracks_fts) as rank
            FROM tracks_fts
            JOIN tracks t ON t.id = tracks_fts.rowid
            WHERE tracks_fts MATCH ?
            AND t.filename NOT LIKE '._%%'
            {tf}
            ORDER BY rank
            LIMIT ?
        """, (fts_q, limit)).fetchall()
        return [TrackResult(**dict(r)) for r in rows]
    except Exception:
        return []


def _like_search(conn: sqlite3.Connection, query: str, limit: int,
                 audio_type: str, allow_long: bool = False) -> list[TrackResult]:
    terms = query.strip().split()
    conditions = " AND ".join(
        """(LOWER(filename) LIKE ?
           OR LOWER(COALESCE(folder_name,'')) LIKE ?
           OR LOWER(COALESCE(artist,'')) LIKE ?
           OR LOWER(COALESCE(title,'')) LIKE ?
           OR LOWER(COALESCE(ai_keywords,'')) LIKE ?)"""
        for _ in terms
    )
    tf = _type_filter(audio_type, allow_long).replace("t.audio_type", "audio_type").replace("t.duration_s", "duration_s")
    params = []
    for t in terms:
        like = f"%{t.lower()}%"
        params.extend([like, like, like, like, like])
    params.append(limit)

    rows = conn.execute(f"""
        SELECT id, path, filename, folder_name, project_name, stem_group,
               duration_s, bpm, key_sig, genre, artist, title,
               audio_type, ai_keywords, use_count, 0.0 as rank
        FROM tracks
        WHERE {conditions}
        AND filename NOT LIKE '._%%'
        {tf}
        LIMIT ?
    """, params).fetchall()
    return [TrackResult(**dict(r)) for r in rows]


def _dedupe(results: list[TrackResult], limit: int, offset: int) -> list[TrackResult]:
    """Keep best-ranked result per stem_group (collapses wav/mp3 pairs and variants)."""
    seen: set[str] = set()
    unique = []
    for r in results:
        key = r.stem_group or r.filename.lower()
        if key not in seen:
            seen.add(key)
            unique.append(r)
    return unique[offset: offset + limit]


def _build_fts_query(query: str) -> str:
    terms = [t for t in query.strip().split() if t]
    if not terms:
        return '""'
    return " OR ".join(f'"{t}"' for t in terms)
