import sqlite3
from pathlib import Path
from config import DB_PATH


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    with conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tracks (
                id           INTEGER PRIMARY KEY,
                path         TEXT UNIQUE NOT NULL,
                filename     TEXT NOT NULL,
                folder_name  TEXT,
                project_name TEXT,
                stem_group   TEXT,
                ext          TEXT NOT NULL,
                size_bytes   INTEGER,
                duration_s   REAL,
                bpm          REAL,
                key_sig      TEXT,
                genre        TEXT,
                artist       TEXT,
                title        TEXT,
                audio_type   TEXT DEFAULT 'sfx',
                ai_keywords  TEXT,
                use_count    INTEGER DEFAULT 1,
                indexed_at   TEXT DEFAULT (datetime('now'))
            )
        """)

        for col, definition in [
            ("folder_name",  "TEXT"),
            ("project_name", "TEXT"),
            ("stem_group",   "TEXT"),
            ("bpm",          "REAL"),
            ("key_sig",      "TEXT"),
            ("genre",        "TEXT"),
            ("artist",       "TEXT"),
            ("title",        "TEXT"),
            ("ai_keywords",  "TEXT"),
            ("use_count",    "INTEGER DEFAULT 1"),
        ]:
            try:
                conn.execute(f"ALTER TABLE tracks ADD COLUMN {col} {definition}")
            except sqlite3.OperationalError:
                pass

        # Drop triggers so rebuild is clean
        for trig in ("tracks_ai", "tracks_ad", "tracks_au"):
            conn.execute(f"DROP TRIGGER IF EXISTS {trig}")

        conn.execute("DROP TABLE IF EXISTS tracks_fts")
        conn.execute("""
            CREATE VIRTUAL TABLE tracks_fts
            USING fts5(
                filename,
                folder_name,
                project_name,
                artist,
                title,
                genre,
                ai_keywords,
                content='tracks',
                content_rowid='id'
            )
        """)

    # Rebuild FTS then wire up triggers
    with conn:
        conn.execute("INSERT INTO tracks_fts(tracks_fts) VALUES('rebuild')")

        conn.execute("""
            CREATE TRIGGER tracks_ai AFTER INSERT ON tracks BEGIN
                INSERT INTO tracks_fts(rowid, filename, folder_name, project_name,
                                       artist, title, genre, ai_keywords)
                VALUES (new.id, new.filename,
                        COALESCE(new.folder_name,''), COALESCE(new.project_name,''),
                        COALESCE(new.artist,''), COALESCE(new.title,''),
                        COALESCE(new.genre,''), COALESCE(new.ai_keywords,''));
            END
        """)
        conn.execute("""
            CREATE TRIGGER tracks_ad AFTER DELETE ON tracks BEGIN
                INSERT INTO tracks_fts(tracks_fts, rowid, filename, folder_name, project_name,
                                       artist, title, genre, ai_keywords)
                VALUES ('delete', old.id, old.filename,
                        COALESCE(old.folder_name,''), COALESCE(old.project_name,''),
                        COALESCE(old.artist,''), COALESCE(old.title,''),
                        COALESCE(old.genre,''), COALESCE(old.ai_keywords,''));
            END
        """)
        conn.execute("""
            CREATE TRIGGER tracks_au AFTER UPDATE ON tracks BEGIN
                INSERT INTO tracks_fts(tracks_fts, rowid, filename, folder_name, project_name,
                                       artist, title, genre, ai_keywords)
                VALUES ('delete', old.id, old.filename,
                        COALESCE(old.folder_name,''), COALESCE(old.project_name,''),
                        COALESCE(old.artist,''), COALESCE(old.title,''),
                        COALESCE(old.genre,''), COALESCE(old.ai_keywords,''));
                INSERT INTO tracks_fts(rowid, filename, folder_name, project_name,
                                       artist, title, genre, ai_keywords)
                VALUES (new.id, new.filename,
                        COALESCE(new.folder_name,''), COALESCE(new.project_name,''),
                        COALESCE(new.artist,''), COALESCE(new.title,''),
                        COALESCE(new.genre,''), COALESCE(new.ai_keywords,''));
            END
        """)

    conn.close()


def upsert_track(data: dict) -> int:
    conn = get_conn()
    with conn:
        cur = conn.execute("""
            INSERT INTO tracks (path, filename, folder_name, project_name, stem_group,
                                ext, size_bytes, duration_s, bpm, key_sig, genre,
                                artist, title, audio_type, ai_keywords, use_count)
            VALUES (:path, :filename, :folder_name, :project_name, :stem_group,
                    :ext, :size_bytes, :duration_s, :bpm, :key_sig, :genre,
                    :artist, :title, :audio_type, :ai_keywords, :use_count)
            ON CONFLICT(path) DO UPDATE SET
                filename     = excluded.filename,
                folder_name  = excluded.folder_name,
                project_name = excluded.project_name,
                stem_group   = excluded.stem_group,
                ext          = excluded.ext,
                size_bytes   = excluded.size_bytes,
                duration_s   = excluded.duration_s,
                bpm          = excluded.bpm,
                key_sig      = excluded.key_sig,
                genre        = excluded.genre,
                artist       = excluded.artist,
                title        = excluded.title,
                audio_type   = excluded.audio_type,
                ai_keywords  = excluded.ai_keywords,
                use_count    = excluded.use_count,
                indexed_at   = datetime('now')
        """, data)
        return cur.lastrowid


def path_exists_in_db(path: str) -> bool:
    conn = get_conn()
    row = conn.execute("SELECT id FROM tracks WHERE path = ?", (path,)).fetchone()
    conn.close()
    return row is not None


def get_stats() -> dict:
    conn = get_conn()
    row = conn.execute("""
        SELECT
            COUNT(*)                                                    as total,
            SUM(CASE WHEN audio_type = 'music' THEN 1 ELSE 0 END)      as music,
            SUM(CASE WHEN audio_type = 'sfx'   THEN 1 ELSE 0 END)      as sfx,
            SUM(CASE WHEN ai_keywords IS NOT NULL
                      AND ai_keywords != '' THEN 1 ELSE 0 END)         as with_ai,
            ROUND(SUM(duration_s)/3600, 2)                             as total_hours,
            ROUND(SUM(size_bytes)/1073741824.0, 2)                     as total_gb
        FROM tracks
    """).fetchone()
    conn.close()
    return dict(row)
