# Hound Tools

AI-powered macOS search tools for Aceable's video and audio libraries.  
Built by Steven Wilson (Video Editor IC3) with Claude Code.

---

## ClipHound

Search 4,600+ video clips across Ace Drive A by semantic description, folder name, or filename.

**How it works:**
- SQLite FTS5 index across `filename`, `folder_name`, and Claude Vision `ai_desc`
- Mac Aliases in a Finder folder — Cmd+R reveals original, Option-drag copies
- Filters: clips only / include edits / edits only / horizontal / vertical / greenscreen
- Paginates in sets of 12 ("Next 12" button)

**Setup:**
```bash
cd cliphound
pip3 install -r requirements.txt
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env
python3 agent.py index          # first run — indexes everything with Claude Vision
python3 agent.py search "teen driving highway"
python3 agent.py stats
```

**Build the app:**
```bash
osacompile -l JavaScript -o ~/Desktop/ClipHound.app launchers/cliphound.js
# Apply icon:
# Convert cliphound/ClipHound_App_Logo.png → ICNS and copy to app bundle
```

**Classifier rules (what gets hidden by default):**
- `media_type = 'edit'` — finished exports, demo videos, proof cuts → hidden unless `--include-edits`
- `media_type = 'vfx'` — roto/composite elements → always hidden
- `is_greenscreen = 1` → hidden unless query contains "green"

---

## SoundHound

Search 600+ music tracks and SFX files across Ace Drive A.  
VO/narration files are excluded entirely.

**How it works:**
- SQLite FTS5 index across `filename`, `folder_name`, `artist`, `title`, `genre`, `ai_keywords`
- Artlist folder slugs parsed as free keywords (no API cost)
- Claude text API generates keywords only for ambiguous filenames
- Stem deduplication: WAV + MP3 pairs and labeled variants show as one result
- Duration gates: SFX search hard-capped at 30s (override with "long" in query)

**Setup:**
```bash
cd soundhound
pip3 install -r requirements.txt
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env
python3 agent.py index
python3 agent.py search "whoosh transition" --sfx
python3 agent.py search "upbeat corporate" --music
python3 agent.py stats
```

**Build the app:**
```bash
osacompile -l JavaScript -o ~/Desktop/SoundHound.app launchers/soundhound.js
# Apply icon: SoundHound_App_Logo.png → ICNS → app bundle
```

**Classification signals (stacked):**
1. Folder path: `/04_sfx` → sfx, `/05_music` / artlist slug → music
2. Filename keywords: whoosh, foley, impact → sfx
3. BPM or artist tag → music
4. Duration: >60s → music, <30s → sfx

---

## JXA Launcher Notes

The `.js` files in `launchers/` are JXA (JavaScript for Automation) compiled with `osacompile`.

**Controls that work in JXA ObjC bridge:**
- `NSAlert`, `NSView`, `NSImageView`, `NSSearchField`, `NSButton` (checkbox type 3)
- `$.NSWorkspace.sharedWorkspace.openFile(path)` — opens Finder folder without nested scripting

**Controls that do NOT work:**
- `NSSegmentedControl` (factory method not bridged)
- `NSPopUpButton.alloc.initWithFrame_pullsDown` (not bridged)

**Reading NSButton state:** Use `btn.state == 1` — do NOT use `ObjC.unwrap(btn.state)` (silently fails).

**Nested JXA:** Never call `osascript -l JavaScript` from Python when Python is already running inside a JXA `doShellScript`. Use a temp file handoff instead (see `preview.py` → `PREVIEW_PATH_FILE`).

---

## Watch Paths

```
/Volumes/Ace Drive A/Broll Archive
/Volumes/Ace Drive A/2026
/Volumes/Ace Drive A/Long Form Videos   (SoundHound only)
```

## Data Locations

| App | Database | Thumbnails |
|-----|----------|------------|
| ClipHound | `~/.video-agent/index.db` | `~/.video-agent/thumbnails/` |
| SoundHound | `~/.soundhound/index.db` | — |

## Session Notes

See `SESSION-2026-04-16.md` for full build log, decisions, and lessons learned.
