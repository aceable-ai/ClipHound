from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from database import get_conn


@dataclass
class ClipResult:
    id: int
    path: str
    filename: str
    duration_s: float | None
    width: int | None
    height: int | None
    fps: float | None
    codec: str | None
    thumb_path: str | None
    ai_desc: str | None
    rank: float


def _is_greenscreen_query(query: str) -> bool:
    q = query.lower()
    return any(kw in q for kw in ("green screen", "greenscreen", "green"))


def search(query: str, limit: int = 12, offset: int = 0,
           include_edits: bool = False, edits_only: bool = False,
           orientation: str = 'any') -> list[ClipResult]:
    """
    Full-text search across filename + AI description.
    Falls back to LIKE search if FTS returns nothing.
    Deduplicates by filename, keeping the best-ranked result.
    offset skips the first N unique results (for pagination).

    By default:
    - Excludes full edits (exported marketing videos)
    - Hides greenscreen clips unless query contains 'green' keywords
    include_edits=True  → include full edits alongside clips
    edits_only=True     → show only full edits (for marketing team use)
    """
    fetch = (offset + limit) * 4
    show_greenscreen = _is_greenscreen_query(query)

    conn = get_conn()
    results = _fts_search(conn, query, fetch, include_edits, edits_only, show_greenscreen, orientation)

    if not results:
        results = _like_search(conn, query, fetch, include_edits, edits_only, show_greenscreen, orientation)

    conn.close()
    return _dedupe(results, limit, offset)


def _dedupe(results: list[ClipResult], limit: int, offset: int = 0) -> list[ClipResult]:
    seen: set[str] = set()
    unique = []
    for r in results:
        if r.filename not in seen:
            seen.add(r.filename)
            unique.append(r)

    return unique[offset: offset + limit]


def _orientation_filter(orientation: str) -> str:
    if orientation == 'horizontal':
        return "AND c.width > c.height"
    if orientation == 'vertical':
        return "AND c.height > c.width"
    return ""


def _media_type_filter(include_edits: bool, edits_only: bool) -> str:
    # vfx is always excluded regardless of flags
    if edits_only:
        return "AND c.media_type = 'edit'"
    if not include_edits:
        return "AND c.media_type = 'clip'"
    return "AND c.media_type != 'vfx'"


def _greenscreen_filter(show_greenscreen: bool) -> str:
    return "" if show_greenscreen else "AND c.is_greenscreen = 0"


def _fts_search(conn: sqlite3.Connection, query: str, limit: int,
                include_edits: bool, edits_only: bool, show_greenscreen: bool,
                orientation: str) -> list[ClipResult]:
    fts_query = _build_fts_query(query)
    mt_filter = _media_type_filter(include_edits, edits_only)
    gs_filter = _greenscreen_filter(show_greenscreen)
    or_filter = _orientation_filter(orientation)
    try:
        rows = conn.execute(f"""
            SELECT c.id, c.path, c.filename, c.duration_s, c.width, c.height,
                   c.fps, c.codec, c.thumb_path, c.ai_desc,
                   bm25(clips_fts) as rank
            FROM clips_fts
            JOIN clips c ON c.id = clips_fts.rowid
            WHERE clips_fts MATCH ?
            AND c.filename NOT LIKE '._%%'
            {mt_filter}
            {gs_filter}
            {or_filter}
            ORDER BY rank
            LIMIT ?
        """, (fts_query, limit)).fetchall()
        return [ClipResult(**dict(r)) for r in rows]
    except Exception:
        return []


def _like_search(conn: sqlite3.Connection, query: str, limit: int,
                 include_edits: bool, edits_only: bool, show_greenscreen: bool,
                 orientation: str) -> list[ClipResult]:
    terms = query.strip().split()
    conditions = " AND ".join(
        "(LOWER(filename) LIKE ? OR LOWER(COALESCE(folder_name,'')) LIKE ? OR LOWER(COALESCE(ai_desc,'')) LIKE ?)"
        for _ in terms
    )
    mt_filter = _media_type_filter(include_edits, edits_only).replace("c.", "")
    gs_filter = _greenscreen_filter(show_greenscreen).replace("c.", "")
    or_filter = _orientation_filter(orientation).replace("c.", "")
    params = []
    for t in terms:
        like = f"%{t.lower()}%"
        params.extend([like, like, like])
    params.append(limit)

    rows = conn.execute(f"""
        SELECT id, path, filename, duration_s, width, height,
               fps, codec, thumb_path, ai_desc,
               0.0 as rank
        FROM clips
        WHERE {conditions}
        AND filename NOT LIKE '._%%'
        {mt_filter}
        {gs_filter}
        {or_filter}
        LIMIT ?
    """, params).fetchall()
    return [ClipResult(**dict(r)) for r in rows]


def _build_fts_query(query: str) -> str:
    """Convert plain text query into FTS5 query string."""
    # Wrap each word so FTS5 doesn't choke on special chars
    terms = [t for t in query.strip().split() if t]
    if not terms:
        return '""'
    return " OR ".join(f'"{t}"' for t in terms)
