from __future__ import annotations
import re

# Filename patterns that indicate a finished export / full edit
_EDIT_PATTERNS = [
    r'_16x9',         # aspect ratio in filename = export naming convention
    r'_9x16',
    r'_1x1',
    r'_4x5',
    r'16x9',
    r'9x16',
    r'1x1',
    r'_v\d+',         # version numbers: _v1, _v2, _v12
    r'_[a-z]_\d+\.',  # variant/version like _B_4. or _A_1.
    r'\brough\b',     # rough cuts
    r'\bfinal\b',     # finals
    r'paid.?social',  # paid social exports
    r'ace mode',      # Aceable campaign exports
    r'^aceable\s*[-–]',  # Aceable branded exports
    r'\bproof\b',     # pre-proof / proof review versions
    r'demo.?video',     # demo videos (no \b — underscores break word boundaries)
    r'\breview\b',    # review cuts
    r'_pre_',         # _PRE_ version markers
    r'\bqpbi\b',      # internal production codes
    r'\bsizzle\b',    # sizzle reels
    r'\bcut\b',       # rough cut, director's cut, etc.
]

# AI description patterns that indicate overlay graphics or multi-shot edits.
# Only include patterns that would NEVER appear in a description of raw broll.
# Avoid: "text overlay", "montage", "split screen" — too broad, fire on laptop screens / scene descriptions.
_EDIT_AI_PATTERNS = [
    r'infographic',
    r'motion graphic',
    r'lower.?third',
    r'title card',
    r'end card',
    r'end screen',
    r'animated text',
    r'graphic overlay',
    r'data visualization',
    r'progress.?bar',
    r'donut.?chart',
    r'pie.?chart',
    r'percentage.?circle',
    r'multiple.?shots',
    r'multiple.?clips',
    r'editing.?software.?interface',
    r'video.?editing.?timeline',
]

# VFX compositing elements — excluded from all searches, including --include-edits
# Only used in After Effects on complex builds
_VFX_PATTERNS = [
    r'\broto\b',      # rotoscoped / masked clips with black backgrounds
]

# Greenscreen / chroma key indicators in filename
_GREEN_PATTERNS = [
    r'\bgreen\b',
    r'\bgreenscreen\b',
    r'\bgreen.?screen\b',
    r'\bchroma\b',
    r'\bchromakey\b',
]

# Duration threshold: clips longer than this are treated as edits
_EDIT_DURATION_S = 180  # 3 minutes


def classify_clip(data: dict) -> tuple[str, int]:
    """
    Returns (media_type, is_greenscreen).
    media_type: 'clip' | 'edit' | 'vfx'
      - clip: raw broll, stock footage — shown by default
      - edit: finished exports, campaign videos — hidden by default, shown with --include-edits
      - vfx:  compositing elements (roto, mattes) — always hidden
    is_greenscreen: 0 | 1
    """
    filename = (data.get("filename") or "").lower()
    duration = data.get("duration_s") or 0

    # --- Greenscreen detection ---
    is_greenscreen = int(any(re.search(p, filename) for p in _GREEN_PATTERNS))

    # --- VFX elements (always excluded) ---
    if any(re.search(p, filename, re.IGNORECASE) for p in _VFX_PATTERNS):
        return "vfx", is_greenscreen

    # --- Edit detection ---
    has_edit_pattern = any(re.search(p, filename, re.IGNORECASE) for p in _EDIT_PATTERNS)
    is_long = duration > _EDIT_DURATION_S

    # 9:16 aspect ratio with SEO-style name = social export
    w = data.get("width") or 0
    h = data.get("height") or 0
    is_social_ratio = (h > 0 and w > 0 and h > w * 1.3)
    has_seo_name = bool(re.search(r'^[a-z0-9][a-z0-9-]{10,}\.', filename))
    is_social_export = is_social_ratio and has_seo_name

    # AI vision: overlay graphics or multi-shot edits are never raw broll
    ai_desc = (data.get("ai_desc") or "").lower()
    has_graphics_overlay = any(re.search(p, ai_desc) for p in _EDIT_AI_PATTERNS)

    media_type = "edit" if (has_edit_pattern or is_long or is_social_export or has_graphics_overlay) else "clip"

    return media_type, is_greenscreen
