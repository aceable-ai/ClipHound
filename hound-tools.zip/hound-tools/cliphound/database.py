import sqlite3
from pathlib import Path
from config import DB_PATH, THUMBS_DIR


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    THUMBS_DIR.mkdir(parents=True, exist_ok=True)

    conn = get_conn()
    with conn:
        # Main clips table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS clips (
                id             INTEGER PRIMARY KEY,
                path           TEXT UNIQUE NOT NULL,
                filename       TEXT NOT NULL,
                ext            TEXT NOT NULL,
                size_bytes     INTEGER,
                duration_s     REAL,
                width          INTEGER,
                height         INTEGER,
                fps            REAL,
                codec          TEXT,
                thumb_path     TEXT,
                ai_desc        TEXT,
                media_type     TEXT DEFAULT 'clip',
                is_greenscreen INTEGER DEFAULT 0,
                folder_name    TEXT,
                indexed_at     TEXT DEFAULT (datetime('now'))
            )
        """)

        # Migrate existing DBs that don't have newer columns yet
        for col, definition in [
            ("media_type",     "TEXT DEFAULT 'clip'"),
            ("is_greenscreen", "INTEGER DEFAULT 0"),
            ("folder_name",    "TEXT"),
        ]:
            try:
                conn.execute(f"ALTER TABLE clips ADD COLUMN {col} {definition}")
            except sqlite3.OperationalError:
                pass  # Column already exists

        # Drop triggers so bulk migrations don't fire against a stale FTS
        for trig in ("clips_ai", "clips_ad", "clips_au"):
            conn.execute(f"DROP TRIGGER IF EXISTS {trig}")

        # Drop + recreate FTS with the current 3-column schema
        conn.execute("DROP TABLE IF EXISTS clips_fts")
        conn.execute("""
            CREATE VIRTUAL TABLE clips_fts
            USING fts5(
                filename,
                folder_name,
                ai_desc,
                content='clips',
                content_rowid='id'
            )
        """)

    # --- Bulk migrations (no triggers active, safe to UPDATE) ---
    _backfill_folder_names(conn)
    _classify_existing(conn)

    with conn:
        # Rebuild FTS from the fully-populated clips table in one pass
        conn.execute("INSERT INTO clips_fts(clips_fts) VALUES('rebuild')")

        # Recreate incremental-sync triggers for future inserts/updates/deletes
        conn.execute("""
            CREATE TRIGGER clips_ai
            AFTER INSERT ON clips BEGIN
                INSERT INTO clips_fts(rowid, filename, folder_name, ai_desc)
                VALUES (new.id, new.filename, COALESCE(new.folder_name, ''), COALESCE(new.ai_desc, ''));
            END
        """)
        conn.execute("""
            CREATE TRIGGER clips_ad
            AFTER DELETE ON clips BEGIN
                INSERT INTO clips_fts(clips_fts, rowid, filename, folder_name, ai_desc)
                VALUES ('delete', old.id, old.filename, COALESCE(old.folder_name, ''), COALESCE(old.ai_desc, ''));
            END
        """)
        conn.execute("""
            CREATE TRIGGER clips_au
            AFTER UPDATE ON clips BEGIN
                INSERT INTO clips_fts(clips_fts, rowid, filename, folder_name, ai_desc)
                VALUES ('delete', old.id, old.filename, COALESCE(old.folder_name, ''), COALESCE(old.ai_desc, ''));
                INSERT INTO clips_fts(rowid, filename, folder_name, ai_desc)
                VALUES (new.id, new.filename, COALESCE(new.folder_name, ''), COALESCE(new.ai_desc, ''));
            END
        """)

    conn.close()


def _backfill_folder_names(conn: sqlite3.Connection):
    """Populate folder_name for any clips missing it."""
    rows = conn.execute(
        "SELECT id, path FROM clips WHERE folder_name IS NULL OR folder_name = ''"
    ).fetchall()
    if not rows:
        return
    with conn:
        for row in rows:
            folder = Path(row["path"]).parent.name
            conn.execute("UPDATE clips SET folder_name = ? WHERE id = ?", (folder, row["id"]))


def _classify_existing(conn: sqlite3.Connection):
    """Classify any clips that haven't been tagged yet."""
    from classifier import classify_clip
    rows = conn.execute(
        "SELECT id, filename, duration_s, width, height, codec, ai_desc FROM clips"
    ).fetchall()
    with conn:
        for row in rows:
            media_type, is_greenscreen = classify_clip(dict(row))
            conn.execute(
                "UPDATE clips SET media_type = ?, is_greenscreen = ? WHERE id = ?",
                (media_type, is_greenscreen, row["id"]),
            )


def upsert_clip(data: dict) -> int:
    """Insert or update a clip record. Returns rowid."""
    conn = get_conn()
    with conn:
        cur = conn.execute("""
            INSERT INTO clips (path, filename, folder_name, ext, size_bytes, duration_s,
                               width, height, fps, codec, thumb_path, ai_desc,
                               media_type, is_greenscreen)
            VALUES (:path, :filename, :folder_name, :ext, :size_bytes, :duration_s,
                    :width, :height, :fps, :codec, :thumb_path, :ai_desc,
                    :media_type, :is_greenscreen)
            ON CONFLICT(path) DO UPDATE SET
                filename       = excluded.filename,
                folder_name    = excluded.folder_name,
                ext            = excluded.ext,
                size_bytes     = excluded.size_bytes,
                duration_s     = excluded.duration_s,
                width          = excluded.width,
                height         = excluded.height,
                fps            = excluded.fps,
                codec          = excluded.codec,
                thumb_path     = excluded.thumb_path,
                ai_desc        = excluded.ai_desc,
                media_type     = excluded.media_type,
                is_greenscreen = excluded.is_greenscreen,
                indexed_at     = datetime('now')
        """, data)
        return cur.lastrowid


def path_exists_in_db(path: str) -> bool:
    conn = get_conn()
    row = conn.execute("SELECT id FROM clips WHERE path = ?", (path,)).fetchone()
    conn.close()
    return row is not None


def get_stats() -> dict:
    conn = get_conn()
    row = conn.execute("""
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN ai_desc IS NOT NULL AND ai_desc != '' THEN 1 ELSE 0 END) as with_vision,
            SUM(CASE WHEN thumb_path IS NOT NULL THEN 1 ELSE 0 END) as with_thumb,
            SUM(CASE WHEN media_type = 'clip' THEN 1 ELSE 0 END) as clips,
            SUM(CASE WHEN media_type = 'edit' THEN 1 ELSE 0 END) as edits,
            SUM(CASE WHEN media_type = 'vfx'  THEN 1 ELSE 0 END) as vfx,
            SUM(CASE WHEN is_greenscreen = 1 THEN 1 ELSE 0 END) as greenscreen,
            ROUND(SUM(duration_s)/3600, 2) as total_hours,
            ROUND(SUM(size_bytes)/1073741824.0, 2) as total_gb
        FROM clips
    """).fetchone()
    conn.close()
    return dict(row)
