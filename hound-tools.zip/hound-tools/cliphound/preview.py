from __future__ import annotations

import re
import subprocess
from pathlib import Path

from config import PREVIEW_DIR

PREVIEW_PATH_FILE = "/tmp/cliphound_preview_path.txt"


def _applescript_string(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _sanitize_name(name: str) -> str:
    return re.sub(r'[:/\\*?"<>|]', "_", name)


def _make_alias(source_path: str, dest_folder: str, alias_name: str) -> bool:
    """Create a Mac Alias via AppleScript."""
    script = (
        f'tell application "Finder"\n'
        f'  set srcFile to POSIX file "{_applescript_string(source_path)}" as alias\n'
        f'  set destFolder to POSIX file "{_applescript_string(dest_folder)}" as alias\n'
        f'  make alias file to srcFile at destFolder\n'
        f'  set name of result to "{_applescript_string(alias_name)}"\n'
        f'end tell'
    )
    result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return result.returncode == 0


def build_preview_folder(clips, folder_name: str = "ClipHound Results"):
    """
    Create Mac Aliases on Desktop. Writes the folder path to a temp file
    so the JXA launcher can open it with NSWorkspace (no nested osascript).
    """
    preview_dir = PREVIEW_DIR.parent / folder_name

    if preview_dir.exists():
        subprocess.run(["rm", "-rf", str(preview_dir)], check=True)
    preview_dir.mkdir(parents=True)

    success = 0
    for i, clip in enumerate(clips, start=1):
        alias_name = f"{i:02d}_{_sanitize_name(Path(clip.path).stem)}"
        if _make_alias(clip.path, str(preview_dir), alias_name):
            success += 1

    # Write path for JXA launcher to read — avoids nested osascript/JXA call
    Path(PREVIEW_PATH_FILE).write_text(str(preview_dir))

    return preview_dir, success
