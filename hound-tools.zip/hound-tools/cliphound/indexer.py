from __future__ import annotations

import base64
import json
import os
import subprocess
from pathlib import Path

import anthropic
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn

from config import (
    WATCH_PATHS, VIDEO_EXTENSIONS, FFMPEG, FFPROBE,
    THUMB_WIDTH, THUMB_QUALITY, THUMB_FRAME_PERCENT,
    THUMBS_DIR, VISION_MODEL,
)
from classifier import classify_clip
from database import init_db, upsert_clip, path_exists_in_db

console = Console()

VISION_SYSTEM_PROMPT = (
    "You are a video asset cataloger for a professional video production team. "
    "Describe what you see in this video thumbnail in 1-2 sentences. Focus on: "
    "subject (person/object/scene), action or expression, setting/environment, "
    "and any notable visual qualities (lighting, angle, mood). "
    "Be specific and use keywords a video editor would search for. "
    "Do NOT start with 'This image shows' — just describe directly."
)


def collect_video_files(paths: list[str]) -> list[Path]:
    """Walk watch paths and return all video file paths."""
    files = []
    for root in paths:
        p = Path(root)
        if not p.exists():
            console.print(f"[yellow]Warning:[/yellow] Path not found: {root}")
            continue
        for f in p.rglob("*"):
            if f.is_file() and f.suffix.lower() in VIDEO_EXTENSIONS and not f.name.startswith("._"):
                files.append(f)
    return sorted(files)


def probe_clip(path: Path) -> dict:
    """Run ffprobe and return metadata dict."""
    cmd = [
        FFPROBE, "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        str(path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        data = json.loads(result.stdout)
    except Exception:
        return {}

    fmt = data.get("format", {})
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), {})

    duration = None
    if "duration" in fmt:
        try:
            duration = float(fmt["duration"])
        except ValueError:
            pass
    if duration is None and "duration" in video:
        try:
            duration = float(video["duration"])
        except ValueError:
            pass

    fps = None
    r_frame_rate = video.get("r_frame_rate", "")
    if "/" in r_frame_rate:
        num, den = r_frame_rate.split("/")
        try:
            fps = round(int(num) / int(den), 3) if int(den) else None
        except (ValueError, ZeroDivisionError):
            pass

    return {
        "duration_s": duration,
        "width": video.get("width"),
        "height": video.get("height"),
        "fps": fps,
        "codec": video.get("codec_name"),
        "size_bytes": int(fmt.get("size", 0)) or None,
    }


def extract_thumbnail(path: Path, duration_s: float | None) -> Path | None:
    """Extract a JPEG frame and return its path, or None on failure."""
    thumb_name = path.stem + "_" + str(abs(hash(str(path)))) + ".jpg"
    thumb_path = THUMBS_DIR / thumb_name

    if thumb_path.exists():
        return thumb_path

    seek = 0.0
    if duration_s and duration_s > 1:
        seek = duration_s * THUMB_FRAME_PERCENT

    cmd = [
        FFMPEG, "-y",
        "-ss", str(seek),
        "-i", str(path),
        "-frames:v", "1",
        "-vf", f"scale={THUMB_WIDTH}:-2",
        "-q:v", "5",
        "-f", "image2",
        str(thumb_path),
    ]
    try:
        subprocess.run(cmd, capture_output=True, timeout=30)
        return thumb_path if thumb_path.exists() else None
    except Exception:
        return None


def describe_thumbnail(client: anthropic.Anthropic, thumb_path: Path) -> str | None:
    """Send thumbnail to Claude Vision and return description."""
    try:
        image_data = base64.standard_b64encode(thumb_path.read_bytes()).decode("utf-8")
    except Exception:
        return None

    try:
        response = client.messages.create(
            model=VISION_MODEL,
            max_tokens=150,
            system=[
                {
                    "type": "text",
                    "text": VISION_SYSTEM_PROMPT,
                    "cache_control": {"type": "ephemeral"},  # Cache system prompt
                }
            ],
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/jpeg",
                                "data": image_data,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Describe this video frame.",
                        },
                    ],
                }
            ],
        )
        return response.content[0].text.strip()
    except Exception as e:
        console.print(f"[dim red]Vision error: {e}[/dim red]")
        return None


def run_index(force: bool = False, vision: bool = True):
    """Main indexing function."""
    init_db()

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if vision and not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set. Run without --no-vision or add it to .env[/red]")
        return

    ai_client = anthropic.Anthropic(api_key=api_key) if vision else None

    console.print("[bold]Scanning for video files...[/bold]")
    all_files = collect_video_files(WATCH_PATHS)
    console.print(f"Found [bold]{len(all_files)}[/bold] video files")

    if not force:
        new_files = [f for f in all_files if not path_exists_in_db(str(f))]
        console.print(f"[bold]{len(new_files)}[/bold] new files to index")
    else:
        new_files = all_files
        console.print(f"Force mode: re-indexing all [bold]{len(new_files)}[/bold] files")

    if not new_files:
        console.print("[green]Index is up to date.[/green]")
        return

    indexed = 0
    errors = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Indexing...", total=len(new_files))

        for f in new_files:
            progress.update(task, description=f"[dim]{f.name[:50]}[/dim]")

            meta = probe_clip(f)
            thumb_path = extract_thumbnail(f, meta.get("duration_s"))
            ai_desc = None

            if vision and thumb_path and ai_client:
                ai_desc = describe_thumbnail(ai_client, thumb_path)

            clip_data = {
                "path": str(f),
                "filename": f.name,
                "folder_name": f.parent.name,
                "ext": f.suffix.lower(),
                "size_bytes": meta.get("size_bytes"),
                "duration_s": meta.get("duration_s"),
                "width": meta.get("width"),
                "height": meta.get("height"),
                "fps": meta.get("fps"),
                "codec": meta.get("codec"),
                "thumb_path": str(thumb_path) if thumb_path else None,
                "ai_desc": ai_desc,
            }
            media_type, is_greenscreen = classify_clip(clip_data)
            clip_data["media_type"] = media_type
            clip_data["is_greenscreen"] = is_greenscreen

            try:
                upsert_clip(clip_data)
                indexed += 1
            except Exception as e:
                console.print(f"[red]DB error for {f.name}: {e}[/red]")
                errors += 1

            progress.advance(task)

    console.print(f"\n[green]Done.[/green] Indexed: {indexed}  Errors: {errors}")
