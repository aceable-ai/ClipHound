import os
from pathlib import Path

# Directories to index
WATCH_PATHS = [
    "/Volumes/Ace Drive A/Broll Archive",
    "/Volumes/Ace Drive A/2026",
]

# Local data directory
DATA_DIR = Path.home() / ".video-agent"
DB_PATH = DATA_DIR / "index.db"
THUMBS_DIR = DATA_DIR / "thumbnails"

# Thumbnail settings
THUMB_WIDTH = 640
THUMB_QUALITY = 85
THUMB_FRAME_PERCENT = 0.10  # Grab frame at 10% of clip duration

# Claude model for vision descriptions
VISION_MODEL = "claude-haiku-4-5-20251001"

# Preview folder on Desktop
PREVIEW_DIR = Path.home() / "Desktop" / "ClipHound Results"

# Supported video extensions
VIDEO_EXTENSIONS = {
    ".mp4", ".mov", ".mxf", ".avi", ".mkv",
    ".m4v", ".r3d", ".braw", ".mts", ".m2ts",
    ".wmv", ".flv", ".webm", ".dv", ".3gp",
}

# FFmpeg / ffprobe paths
FFMPEG = "/opt/homebrew/bin/ffmpeg"
FFPROBE = "/opt/homebrew/bin/ffprobe"
