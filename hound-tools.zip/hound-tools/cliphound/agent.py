#!/usr/bin/env python3
from __future__ import annotations
"""
ClipHound — CLI
Usage:
  python agent.py index              # Index new files (with vision)
  python agent.py index --no-vision  # Index metadata only (no Claude API)
  python agent.py index --force      # Re-index everything
  python agent.py search "keyword"   # Search clips
  python agent.py search "keyword" --limit 30
  python agent.py stats              # Show index stats
"""
import argparse
import os
import sys
from pathlib import Path

# Load .env before anything imports config
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

from rich.console import Console
from rich.table import Table

from database import get_stats, init_db
from indexer import run_index
from searcher import search
from preview import build_preview_folder

console = Console()


def cmd_index(args):
    run_index(force=args.force, vision=not args.no_vision)


def cmd_search(args):
    query = " ".join(args.query)
    orientation = 'any'
    if getattr(args, 'horizontal', False):
        orientation = 'horizontal'
    elif getattr(args, 'vertical', False):
        orientation = 'vertical'

    results = search(query, limit=args.limit, offset=args.offset,
                     include_edits=args.include_edits, edits_only=args.edits_only,
                     orientation=orientation)

    if not results:
        console.print(f"[yellow]No results for:[/yellow] {query}")
        return

    console.print(f"\n[bold green]ClipHound — {len(results)} clip(s)[/bold green] for: [italic]{query}[/italic]\n")

    table = Table(show_header=True, header_style="bold cyan", show_lines=True)
    table.add_column("#", width=3, justify="right")
    table.add_column("Filename", min_width=30)
    table.add_column("Duration", width=9, justify="right")
    table.add_column("Res", width=11)
    table.add_column("AI Description", min_width=40)

    for i, clip in enumerate(results, start=1):
        dur = _fmt_duration(clip.duration_s)
        res = f"{clip.width}×{clip.height}" if clip.width else "—"
        desc = (clip.ai_desc or "—")[:80]
        table.add_row(str(i), clip.filename, dur, res, desc)

    console.print(table)

    preview_dir, count = build_preview_folder(results)
    console.print(f"\n[green]Built {count} clip alias(es) — opening in Finder...[/green]")


def cmd_stats(args):
    init_db()
    s = get_stats()
    console.print("\n[bold]ClipHound — Index Stats[/bold]")
    console.print(f"  Total indexed:    [cyan]{s['total']}[/cyan]")
    console.print(f"  Individual clips: [cyan]{s['clips'] or 0}[/cyan]")
    console.print(f"  Full edits:       [cyan]{s['edits'] or 0}[/cyan]")
    console.print(f"  VFX elements:     [cyan]{s['vfx'] or 0}[/cyan]")
    console.print(f"  Greenscreen:      [cyan]{s['greenscreen'] or 0}[/cyan]")
    console.print(f"  With AI vision:   [cyan]{s['with_vision'] or 0}[/cyan]")
    console.print(f"  With thumbnail:   [cyan]{s['with_thumb'] or 0}[/cyan]")
    console.print(f"  Total duration:   [cyan]{s['total_hours'] or 0} hrs[/cyan]")
    console.print(f"  Total size:       [cyan]{s['total_gb'] or 0} GB[/cyan]\n")


def _fmt_duration(secs: float | None) -> str:
    if secs is None:
        return "—"
    m, s = divmod(int(secs), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def main():
    parser = argparse.ArgumentParser(
        prog="cliphound",
        description="ClipHound — search your footage library",
    )
    sub = parser.add_subparsers(dest="command")

    # index
    p_index = sub.add_parser("index", help="Scan and index video files")
    p_index.add_argument("--force", action="store_true", help="Re-index all files")
    p_index.add_argument("--no-vision", action="store_true", help="Skip Claude Vision (metadata only)")
    p_index.set_defaults(func=cmd_index)

    # search
    p_search = sub.add_parser("search", help="Search the clip index")
    p_search.add_argument("query", nargs="+", help="Search terms")
    p_search.add_argument("--limit", type=int, default=12, help="Max results (default: 12)")
    p_search.add_argument("--offset", type=int, default=0, help="Skip first N results (for paging)")
    p_search.add_argument("--include-edits", action="store_true", help="Include full edits alongside clips")
    p_search.add_argument("--edits-only", action="store_true", help="Show only full edits (marketing assets)")
    p_search.add_argument("--horizontal", action="store_true", help="Landscape clips only (width > height)")
    p_search.add_argument("--vertical", action="store_true", help="Portrait clips only (height > width)")
    p_search.set_defaults(func=cmd_search)

    # stats
    p_stats = sub.add_parser("stats", help="Show index statistics")
    p_stats.set_defaults(func=cmd_stats)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
